# WaterThePlant

# https://fadimeyaren.github.io/WaterThePlant/

# This is our website project for web programming course in Antalya Bilim University. 

# We are Yaren, Zeynep, Duru and Rüya. Purpose of this project is creating a website for taking notes and to do list and control our study time. 


## Technologies Used

- HTML5
- CSS3
- JavaScript